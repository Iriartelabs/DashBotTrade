import streamlit as st

def on_ok_clicked():
    # Aquí se define la lógica; por ejemplo, actualizar el mensaje
    st.session_state["hola_msg"] = "Hola, Mundo"