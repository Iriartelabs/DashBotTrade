import streamlit as st
from addons.hola_addon.src.hola_addon import on_ok_clicked  # función definida en hola_addon.py

def render():
    st.header("hola_addon")  # Título del addon en la interfaz

    # Usamos st.session_state para conservar el mensaje
    if "hola_msg" not in st.session_state:
        st.session_state["hola_msg"] = ""

    st.write(st.session_state["hola_msg"])  # Muestra el mensaje

    # Botón "OK" que, al pulsarlo, se ejecuta la función en hola_addon.py
    if st.button("OK"):
        on_ok_clicked()  # Llama a la función de lógica del addon
        #st.experimental_rerun()  # Actualiza la UI